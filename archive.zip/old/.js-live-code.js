
console.log(console)
$( document ).ready(function() {
    $( 'body' ).css( 'background-color' , 'gold' )  ;
});
