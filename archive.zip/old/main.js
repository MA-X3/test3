console.clear();
console.log("qwe");
$( document ).ready(function() {
    $( 'body' ).css( 'background-color' , 'gold' )  ;
});
